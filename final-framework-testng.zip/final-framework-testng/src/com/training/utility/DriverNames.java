package com.training.utility;

public interface DriverNames {
	String CHROME ="CHROME";
	String FIREFOX = "FIREFOX";
	String IE ="IE";
	String PHANTOM ="PHANTOM";
}